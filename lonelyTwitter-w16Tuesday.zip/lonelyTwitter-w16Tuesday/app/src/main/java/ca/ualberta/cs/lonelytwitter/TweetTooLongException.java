package ca.ualberta.cs.lonelytwitter;

/**
 * Created by romansky on 1/12/16.
 */
public class TweetTooLongException extends Exception {
}
