package ca.ualberta.cs.lonelytwitter;

/**
 * Created by runqi on 1/12/16.
 */
public abstract class BM {
    public abstract String getmood();

}
